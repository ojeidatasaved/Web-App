import pandas as pd
import plotly.graph_objects as go
import numpy as np


df_new = pd.read_csv('new2.csv')
df = pd.read_csv('data.csv')



#merging data sets

full_data = pd.merge(df,df_new, on = ["station"],how='left')
#print(full_data)

full_data['colour'] = full_data['type'].replace(['discharge','suction'],['orange','red'])

print(full_data['colour'])


print(full_data)

#full_data['timestamp'] = pd.to_datetime(full_data['timestamp'])

 
#add a new column called colour
fig = go.Figure(layout={"title":"Pressure Profile"})
times = full_data["timestamp"].unique()
for t in  times:
    dfp = full_data[full_data["timestamp"]==t]
    fig.add_trace(
        #TODO
        #Replace table function (go.table) with go.scatter
        #Note the y is pressure and x are the stations 
        #y axis is pressure and x axis should be distance and the names of the x axis should be the station names
        go.Scatter(x= dfp['distance'],
                   y=dfp['value'],
                   visible = False,
                    marker=dict(size = 10, color = dfp['colour'] )
                    #  legendgroup='suction',
                    #  showlegend=True
                    #  name='suction'
            ) 
    )


   

    



#Dont touch anything above this    
    
fig.data[2].visible = True

# Create and add slider
steps = []
for  i in range(len(fig.data)):
    step = dict(
        method="update",
        args=[{"visible": [False] * len(fig.data)}],
        label= times[i],  # layout attribute
       
    )
    step["args"][0]["visible"][i] = True  # Toggle i'th trace to "visible"
    steps.append(step)


fig.update_layout( 
    sliders = [dict(
    active=2,
    currentvalue={"prefix": "Date & Time: "},
    pad={"t": 100} ,
    steps=steps
    )]
  


   
   
    
 )

fig.update_xaxes(
    title ="Station",
    tickfont=dict(color="brown"),
    tickmode='array',
    tickvals=[0, 230, 380],
    ticktext=['AAA', 'BBB', 'CCC']
    
   
     
    



)


fig.update_yaxes(
    ticksuffix = "psi",
    title ="Pressure",
    range=[0,350]

)
    





   
fig.show()


print(fig.show())


