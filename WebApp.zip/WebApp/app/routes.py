from app import app
from flask import render_template,url_for
import pandas as pd
import json
import plotly
import plotly.express as px
import plotly.graph_objects as go
import numpy as np


@app.route('/')
def index():
   
   df_new = pd.read_csv('new2.csv')
   df = pd.read_csv('data.csv')



#merging data sets

   full_data = pd.merge(df,df_new, on = ["Station"],how='left')
#print(full_data)

   full_data['Colour'] = full_data['Type'].replace(['discharge','suction'],['orange','red'])

   print(full_data['Colour'])


   print(full_data)

#full_data['timestamp'] = pd.to_datetime(full_data['timestamp'])

 
#add a new column called colour
   fig1 = go.Figure(layout={"title":"Pressure Profile"})
   times = full_data["Timestamp"].unique()
   for t in  times:
      dfp = full_data[full_data["Timestamp"]==t]
      fig1.add_traces(
        #TODO
        #Replace table function (go.table) with go.scatter
        #Note the y is pressure and x are the stations 
        #y axis is pressure and x axis should be distance and the names of the x axis should be the station names
         go.Scatter(x= dfp['Distance'],
                   y=dfp['Value'],
                   visible = False,
                    marker=dict(size = 10,color = dfp['Colour'] ),
                     # legendgroup='suction',
                     # showlegend=True, 
                     # name='suction'
         )    
      )




#Dont touch anything above this    
    
   fig1.data[2].visible = True

# Create and add slider
   steps = []
   for  i in range(len(fig1.data)):
      step = dict(
      method="update",
      args=[{"visible": [False] * len(fig1.data)}],
      label= times[i],  # layout attribute
       
    )
      step["args"][0]["visible"][i] = True  # Toggle i'th trace to "visible"
      steps.append(step)


   fig1.update_layout( 
      sliders = [dict(
      active=2,
      currentvalue={"prefix": "Date & Time: "},
      pad={"t": 100} ,
      steps=steps
    )], 
    


   
   
    
   )

   fig1.update_xaxes(
      title ="Station",
      tickfont=dict(color="brown"),
      tickmode='array',
      tickvals=[0, 230, 380],
      ticktext=['AAA', 'BBB', 'CCC']
    
   
     
    



   )


   fig1.update_yaxes(
      ticksuffix = "psi",
      title ="Pressure",
      range=[0,350]

   )
    





   
   fig1.show()

   graph1JSON = json.dumps(fig1, cls=plotly.utils.PlotlyJSONEncoder)

   return render_template('index.html',title ="Home", graph1JSON=graph1JSON)